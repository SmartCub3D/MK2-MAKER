/**
 * Marlin 3D Printer Firmware
 * Copyright (C) 2016 MarlinFirmware [https://github.com/MarlinFirmware/Marlin]
 *
 * Based on Sprinter and grbl.
 * Copyright (C) 2011 Camiel Gubbels / Erik van der Zalm
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 */

#ifndef UTF_MAPPER_H
#define UTF_MAPPER_H

#include "language.h"

#if ENABLED(DOGLCD)
  #define HARDWARE_CHAR_OUT(C) u8g.print((char)(C))
#else
  #define HARDWARE_CHAR_OUT(C) lcd.write((char)(C))
#endif

#if DISABLED(SIMULATE_ROMFONT) && ENABLED(DOGLCD)
  #if ENABLED(DISPLAY_CHARSET_ISO10646_1)     \
   || ENABLED(DISPLAY_CHARSET_ISO10646_5)     \
   || ENABLED(DISPLAY_CHARSET_ISO10646_KANA)  \
   || ENABLED(DISPLAY_CHARSET_ISO10646_GREEK) \
   || ENABLED(DISPLAY_CHARSET_ISO10646_TR)
    #define MAPPER_ONE_TO_ONE
  #endif
#else // SIMULATE_ROMFONT || !DOGLCD
  #if DISPLAY_CHARSET_HD44780 == JAPANESE
    #if ENABLED(MAPPER_C2C3)
      const PROGMEM uint8_t utf_recode[] =
           { // 0    1    2    3    4    5    6    7    8    9    a    b    c    d    e    f          This is fair for symbols
               0x20,0x3F,0xEC,0xED,0x3F,0x5C,0x7C,0x3F,0x22,0x63,0x61,0x7F,0x3F,0x3F,0x52,0xB0,  // c2a
             //' '        Ãƒâ€šÃ‚Â¢    Ãƒâ€šÃ‚Â£         Ãƒâ€šÃ‚Â­     l         "    c    a    Ãƒâ€šÃ‚Â«              R
               0xDF,0x3F,0x32,0x33,0x27,0xE4,0xF1,0xA5,0x2C,0x31,0xDF,0x7E,0x3F,0x3F,0x3F,0x3F,  // c2b but relatively bad for letters.
             // Ãƒâ€šÃ‚Â°         2    3    `    N    p    .    ,    1    Ãƒâ€šÃ‚Â°    Ãƒâ€šÃ‚Â»
               0x3F,0x3F,0x3F,0x3F,0xE1,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,  // c38
             //                     ÃƒÆ’Ã‚Â¤
               0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0xEF,0x78,0x3F,0x3F,0x3F,0x3F,0xF5,0x3F,0x3F,0xE2,  // c39 missing characters display as '?'
             //                               ÃƒÆ’Ã‚Â¶    x                        ÃƒÆ’Ã‚Â¼              ÃƒÆ’Ã…Â¸
               0x3F,0x3F,0x3F,0x3F,0xE1,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,  // c3a
             //                     ÃƒÆ’Ã‚Â¤
               0x3F,0xEE,0x3F,0x3F,0x3F,0x3F,0xEF,0xFD,0x3F,0x3F,0x3F,0x3F,0xF5,0x3F,0x3F,0x3F   // c3b
             //      n                        ÃƒÆ’Ã‚Â¶    ÃƒÆ’Ã‚Â·                        ÃƒÆ’Ã‚Â¼
           };
    #elif ENABLED(MAPPER_E382E383)
      const PROGMEM uint8_t utf_recode[] =
           { // 0    1    2    3    4    5    6    7    8    9    a    b    c    d    e    f
               0x3D,0xB1,0xB1,0xA8,0xB2,0xA9,0xB3,0xAA,0xB4,0xAB,0xB5,0xB6,0xB6,0xB7,0xB7,0xB8,  // e382a Please test and correct
             // =    ÃƒÂ£Ã¢â‚¬Å¡Ã‚Â¢    ÃƒÂ£Ã¢â‚¬Å¡Ã‚Â¢    ÃƒÂ£Ã¢â‚¬Å¡Ã‚Â£    ÃƒÂ£Ã¢â‚¬Å¡Ã‚Â¤    ÃƒÂ£Ã¢â‚¬Å¡Ã‚Â¥    ÃƒÂ£Ã¢â‚¬Å¡Ã‚Â¦    ÃƒÂ£Ã¢â‚¬Å¡Ã‚Â§    ÃƒÂ£Ã¢â‚¬Å¡Ã‚Â¨    ÃƒÂ£Ã¢â‚¬Å¡Ã‚Â©    ÃƒÂ£Ã¢â‚¬Å¡Ã‚Âª   ÃƒÂ£Ã¢â‚¬Å¡Ã‚Â¬    ÃƒÂ£Ã¢â‚¬Å¡Ã‚Â¬    ÃƒÂ£Ã¢â‚¬Å¡Ã‚Â­   ÃƒÂ£Ã¢â‚¬Å¡Ã‚Â­    ÃƒÂ£Ã¢â‚¬Å¡Ã‚Â¯
               0xB8,0xB9,0xB9,0xBA,0xBA,0xBB,0xBB,0xBC,0xBC,0xBD,0xBD,0xBE,0xBE,0xBF,0xBF,0xC0,  // e382b
             // ÃƒÂ£Ã¢â‚¬Å¡Ã‚Â¯    ÃƒÂ£Ã¢â‚¬Å¡Ã‚Â±    ÃƒÂ£Ã¢â‚¬Å¡Ã‚Â±   ÃƒÂ£Ã¢â‚¬Å¡Ã‚Â³    ÃƒÂ£Ã¢â‚¬Å¡Ã‚Â³    ÃƒÂ£Ã¢â‚¬Å¡Ã‚Âµ    ÃƒÂ£Ã¢â‚¬Å¡Ã‚Âµ    ÃƒÂ£Ã¢â‚¬Å¡Ã‚Â·    ÃƒÂ£Ã¢â‚¬Å¡Ã‚Â·   ÃƒÂ£Ã¢â‚¬Å¡Ã‚Â¹    ÃƒÂ£Ã¢â‚¬Å¡Ã‚Â¹    ÃƒÂ£Ã¢â‚¬Å¡Ã‚Â»    ÃƒÂ£Ã¢â‚¬Å¡Ã‚Â»    ÃƒÂ£Ã¢â‚¬Å¡Ã‚Â½   ÃƒÂ£Ã¢â‚¬Å¡Ã‚Â½    ÃƒÂ£Ã¢â‚¬Å¡Ã‚Â¿
               0xC0,0xC1,0xC1,0xC2,0xC2,0xC2,0xC3,0xC3,0xC4,0xC4,0xC5,0xC6,0xC7,0xC8,0xC9,0xCA,  // e3838
             // ÃƒÂ£Ã¢â‚¬Å¡Ã‚Â¿    ÃƒÂ£Ã†â€™Ã¯Â¿Â½    ÃƒÂ£Ã†â€™Ã¯Â¿Â½    ÃƒÂ£Ã†â€™Ã†â€™    ÃƒÂ£Ã†â€™Ã†â€™    ÃƒÂ£Ã†â€™Ã†â€™    ÃƒÂ£Ã†â€™Ã¢â‚¬Â    ÃƒÂ£Ã†â€™Ã¢â‚¬Â     ÃƒÂ£Ã†â€™Ã‹â€     ÃƒÂ£Ã†â€™Ã‹â€     ÃƒÂ£Ã†â€™Ã…Â     ÃƒÂ£Ã†â€™Ã¢â‚¬Â¹    ÃƒÂ£Ã†â€™Ã…â€™    ÃƒÂ£Ã†â€™Ã¯Â¿Â½   ÃƒÂ£Ã†â€™Ã…Â½    ÃƒÂ£Ã†â€™Ã¯Â¿Â½
               0xCA,0xCA,0xCB,0xCB,0xCB,0xCC,0xCC,0xCC,0xCD,0xCD,0xCD,0xCE,0xCE,0xCE,0xCF,0xD0,  // e3839
             // ÃƒÂ£Ã†â€™Ã¯Â¿Â½    ÃƒÂ£Ã†â€™Ã¯Â¿Â½    ÃƒÂ£Ã†â€™Ã¢â‚¬â„¢   ÃƒÂ£Ã†â€™Ã¢â‚¬â„¢    ÃƒÂ£Ã†â€™Ã¢â‚¬â„¢     ÃƒÂ£Ã†â€™Ã¢â‚¬Â¢    ÃƒÂ£Ã†â€™Ã¢â‚¬Â¢   ÃƒÂ£Ã†â€™Ã¢â‚¬Â¢    ÃƒÂ£Ã†â€™Ã‹Å“    ÃƒÂ£Ã†â€™Ã‹Å“    ÃƒÂ£Ã†â€™Ã‹Å“    ÃƒÂ£Ã†â€™Ã¢â‚¬Âº    ÃƒÂ£Ã†â€™Ã¢â‚¬Âº    ÃƒÂ£Ã†â€™Ã¢â‚¬Âº   ÃƒÂ£Ã†â€™Ã…Â¾    ÃƒÂ£Ã†â€™Ã…Â¸
               0xD1,0xD2,0xD3,0xD4,0xD4,0xD5,0xD5,0xAE,0xD6,0xD7,0xD8,0xD9,0xDA,0xDB,0xDC,0xDC,  // e383a
             // ÃƒÂ£Ã†â€™Ã‚Â     ÃƒÂ£Ã†â€™Ã‚Â¡    ÃƒÂ£Ã†â€™Ã‚Â¢    ÃƒÂ£Ã†â€™Ã‚Â£   ÃƒÂ£Ã†â€™Ã‚Â£    ÃƒÂ£Ã†â€™Ã‚Â¦    ÃƒÂ£Ã†â€™Ã‚Â¦    ÃƒÂ£Ã†â€™Ã‚Â§    ÃƒÂ£Ã†â€™Ã‚Â¨    ÃƒÂ£Ã†â€™Ã‚Â©    ÃƒÂ£Ã†â€™Ã‚Âª    ÃƒÂ£Ã†â€™Ã‚Â«    ÃƒÂ£Ã†â€™Ã‚Â¬    ÃƒÂ£Ã†â€™Ã‚Â­   ÃƒÂ£Ã†â€™Ã‚Â¯    ÃƒÂ£Ã†â€™Ã‚Â¯
               0xEC,0xA7,0xA6,0xDD,0xCC,0x3F,0x3F,0x3F,0x3F,0x3F,0xA6,0xA5,0xB0,0xA4,0xA4,0x3F   // e383b
             // ÃƒÂ£Ã†â€™Ã‚Â°    ÃƒÂ£Ã†â€™Ã‚Â±    ÃƒÂ£Ã†â€™Ã‚Â²    ÃƒÂ£Ã†â€™Ã‚Â³    ÃƒÂ£Ã†â€™Ã¢â‚¬Â¢    ?    ?   ?    ?    ?    ÃƒÂ£Ã†â€™Ã‚Â²    ÃƒÂ£Ã†â€™Ã‚Â»    ÃƒÂ£Ã†â€™Ã‚Â¼    ÃƒÂ£Ã†â€™Ã‚Â½    ÃƒÂ£Ã†â€™Ã‚Â½   ?
           };
    #elif ENABLED(MAPPER_D0D1)
      #error "Cyrillic on a JAPANESE display makes no sense. There are no matching symbols."
    #endif

  #elif DISPLAY_CHARSET_HD44780 == WESTERN
    #if ENABLED(MAPPER_C2C3)
      const PROGMEM uint8_t utf_recode[] =
           { // 0    1    2    3    4    5    6    7    8    9    a    b    c    d    e    f   This is relative complete.
               0x20,0xA1,0xA2,0xA3,0xA4,0xA5,0xA6,0xA7,0x22,0xA9,0xAA,0xAB,0x3F,0x3F,0xAE,0x3F,  // c2aÃƒâ€šÃ‚Â Ãƒâ€šÃ‚Â¡Ãƒâ€šÃ‚Â¢Ãƒâ€šÃ‚Â£Ãƒâ€šÃ‚Â¤Ãƒâ€šÃ‚Â¥Ãƒâ€šÃ‚Â¦Ãƒâ€šÃ‚Â§Ãƒâ€šÃ‚Â¨Ãƒâ€šÃ‚Â©Ãƒâ€šÃ‚ÂªÃƒâ€šÃ‚Â«Ãƒâ€šÃ‚Â¬Ãƒâ€šÃ‚Â­Ãƒâ€šÃ‚Â®Ãƒâ€šÃ‚Â¯
             //' '   Ãƒâ€šÃ‚Â¡    Ãƒâ€šÃ‚Â¢    Ãƒâ€šÃ‚Â£    Ãƒâ€šÃ‚Â¤    Ãƒâ€šÃ‚Â¥    Ãƒâ€šÃ‚Â¦    Ãƒâ€šÃ‚Â§    "    Ãƒâ€šÃ‚Â©    Ãƒâ€šÃ‚Âª    Ãƒâ€šÃ‚Â«    ?    ?    Ãƒâ€šÃ‚Â®    ?
               0xB0,0xB1,0xB2,0xB3,0x27,0xB5,0xB6,0xB7,0x2C,0xB9,0xBA,0xBB,0xBC,0xBD,0xBE,0xBF,  // c2b Ãƒâ€šÃ‚Â°Ãƒâ€šÃ‚Â±Ãƒâ€šÃ‚Â²Ãƒâ€šÃ‚Â³Ãƒâ€šÃ‚Â´Ãƒâ€šÃ‚ÂµÃƒâ€šÃ‚Â¶Ãƒâ€šÃ‚Â·Ãƒâ€šÃ‚Â¸Ãƒâ€šÃ‚Â¹Ãƒâ€šÃ‚ÂºÃƒâ€šÃ‚Â»Ãƒâ€šÃ‚Â¼Ãƒâ€šÃ‚Â½Ãƒâ€šÃ‚Â¾Ãƒâ€šÃ‚Â¿
             // Ãƒâ€šÃ‚Â°    Ãƒâ€šÃ‚Â±    Ãƒâ€šÃ‚Â³    Ãƒâ€šÃ‚Â²    ?    Ãƒâ€šÃ‚Âµ    Ãƒâ€šÃ‚Â¶    Ãƒâ€šÃ‚Â·    ,    Ãƒâ€šÃ‚Â¹    Ãƒâ€šÃ‚Âº    Ãƒâ€šÃ‚Â»    Ãƒâ€šÃ‚Â¼    Ãƒâ€šÃ‚Â½    Ãƒâ€šÃ‚Â¾    Ãƒâ€šÃ‚Â¿
               0xC0,0xC1,0xC2,0xC3,0xC4,0xC5,0xC6,0xC7,0xC8,0xC9,0xCA,0xCB,0xCC,0xCD,0xCE,0xCF,  // c38 ÃƒÆ’Ã¢â€šÂ¬ÃƒÆ’Ã¯Â¿Â½ÃƒÆ’Ã†â€™ÃƒÆ’Ã¢â‚¬Å¾ÃƒÆ’Ã¢â‚¬Â¦ÃƒÆ’Ã¢â‚¬Â ÃƒÆ’Ã¢â‚¬Â¡ÃƒÆ’Ã‹â€ ÃƒÆ’Ã¢â‚¬Â°ÃƒÆ’Ã…Â ÃƒÆ’Ã¢â‚¬Â¹ÃƒÆ’Ã…â€™ÃƒÆ’Ã¯Â¿Â½ÃƒÆ’Ã…Â½ÃƒÆ’Ã¯Â¿Â½
             // ÃƒÆ’Ã¢â€šÂ¬    ÃƒÆ’Ã¯Â¿Â½    ÃƒÆ’Ã¢â‚¬Å¡    ÃƒÆ’Ã†â€™    ÃƒÆ’Ã¢â‚¬Å¾    ÃƒÆ’Ã¢â‚¬Â¦    ÃƒÆ’Ã¢â‚¬Â     ÃƒÆ’Ã¢â‚¬Â¡    ÃƒÆ’Ã‹â€     ÃƒÆ’Ã¢â‚¬Â°    ÃƒÆ’Ã…Â     ÃƒÆ’Ã¢â‚¬Â¹    ÃƒÆ’Ã…â€™    ÃƒÆ’Ã¯Â¿Â½    ÃƒÆ’Ã…Â½    ÃƒÆ’Ã¯Â¿Â½
               0xD0,0xD1,0xD2,0xD3,0xD4,0xD5,0xD6,0xD7,0xD8,0xD9,0xDA,0xDB,0xDC,0xDD,0xDE,0xDF,  // c39 ÃƒÆ’Ã¯Â¿Â½ÃƒÆ’Ã¢â‚¬ËœÃƒÆ’Ã¢â‚¬Å“ÃƒÆ’Ã¢â‚¬ï¿½ÃƒÆ’Ã¢â‚¬Â¢ÃƒÆ’Ã¢â‚¬â€œÃƒÆ’Ã¢â‚¬â€�ÃƒÆ’Ã‹Å“ÃƒÆ’Ã¢â€žÂ¢ÃƒÆ’Ã…Â¡ÃƒÆ’Ã¢â‚¬ÂºÃƒÆ’Ã…â€œÃƒÆ’Ã¯Â¿Â½ÃƒÆ’Ã…Â¾ÃƒÆ’Ã…Â¸
             // ÃƒÆ’Ã¯Â¿Â½    ÃƒÆ’Ã¢â‚¬Ëœ    ÃƒÆ’Ã¢â‚¬â„¢    ÃƒÆ’Ã¢â‚¬Å“    ÃƒÆ’Ã¢â‚¬ï¿½    ÃƒÆ’Ã¢â‚¬Â¢    ÃƒÆ’Ã¢â‚¬â€œ    ÃƒÆ’Ã¢â‚¬â€�    ÃƒÆ’Ã‹Å“    ÃƒÆ’Ã¢â€žÂ¢    ÃƒÆ’Ã…Â¡    ÃƒÆ’Ã¢â‚¬Âº    ÃƒÆ’Ã…â€œ    ÃƒÆ’Ã¯Â¿Â½    ÃƒÆ’Ã…Â¾    ÃƒÆ’Ã…Â¸
               0xE0,0xE1,0xE2,0xE3,0xE4,0xE5,0xE6,0xE7,0xE8,0xE9,0xEA,0xEB,0xEC,0xED,0xEE,0xEF,  // c3a ÃƒÆ’Ã‚Â ÃƒÆ’Ã‚Â¡ÃƒÆ’Ã‚Â£ÃƒÆ’Ã‚Â¤ÃƒÆ’Ã‚Â¥ÃƒÆ’Ã‚Â¦ÃƒÆ’Ã‚Â§ÃƒÆ’Ã‚Â¨ÃƒÆ’Ã‚Â©ÃƒÆ’Ã‚ÂªÃƒÆ’Ã‚Â«ÃƒÆ’Ã‚Â¬ÃƒÆ’Ã‚Â­ÃƒÆ’Ã‚Â®ÃƒÆ’Ã‚Â¯
             // ÃƒÆ’Ã‚Â     ÃƒÆ’Ã‚Â¡    ÃƒÆ’Ã‚Â¢    ÃƒÆ’Ã‚Â£    ÃƒÆ’Ã‚Â¤    ÃƒÆ’Ã‚Â¥    ÃƒÆ’Ã‚Â¦    ÃƒÆ’Ã‚Â§    ÃƒÆ’Ã‚Â¨    ÃƒÆ’Ã‚Â©    ÃƒÆ’Ã‚Âª    ÃƒÆ’Ã‚Â«    ÃƒÆ’Ã‚Â¬    ÃƒÆ’Ã‚Â­    ÃƒÆ’Ã‚Â®    ÃƒÆ’Ã‚Â¯
               0xF0,0xF1,0xF2,0xF3,0xF4,0xF5,0xF6,0xF7,0xF8,0xF9,0xFA,0xFB,0xFC,0xFD,0xFE,0xFF   // c3b ÃƒÆ’Ã‚Â°ÃƒÆ’Ã‚Â±ÃƒÆ’Ã‚Â³ÃƒÆ’Ã‚Â´ÃƒÆ’Ã‚ÂµÃƒÆ’Ã‚Â¶ÃƒÆ’Ã‚Â·ÃƒÆ’Ã‚Â¸ÃƒÆ’Ã‚Â¹ÃƒÆ’Ã‚ÂºÃƒÆ’Ã‚Â»ÃƒÆ’Ã‚Â¼ÃƒÆ’Ã‚Â½ÃƒÆ’Ã‚Â¾ÃƒÆ’Ã‚Â¿
             // ÃƒÆ’Ã‚Â°    ÃƒÆ’Ã‚Â±    ÃƒÆ’Ã‚Â²    ÃƒÆ’Ã‚Â³    ÃƒÆ’Ã‚Â´    ÃƒÆ’Ã‚Âµ    ÃƒÆ’Ã‚Â¶    ÃƒÆ’Ã‚Â·    ÃƒÆ’Ã‚Â¸    ÃƒÆ’Ã‚Â¹    ÃƒÆ’Ã‚Âº    ÃƒÆ’Ã‚Â»    ÃƒÆ’Ã‚Â¼    ÃƒÆ’Ã‚Â½    ÃƒÆ’Ã‚Â¾    ÃƒÆ’Ã‚Â¿
           };
    #elif ENABLED(MAPPER_D0D1)
      #define MAPPER_D0D1_MOD
      const PROGMEM uint8_t utf_recode[] =
           {//0    1    2    3    4    5    6    7    8    9    a    b    c    d    e    f
               0x41,0x80,0x42,0x92,0x81,0x45,0x82,0x83,0x84,0x85,0x4B,0x86,0x4D,0x48,0x4F,0x87,  // d0a
             // A    Ãƒï¿½Ã¢â‚¬Ëœ    B    Ãƒï¿½Ã¢â‚¬Å“    Ãƒï¿½Ã¢â‚¬ï¿½    E    Ãƒï¿½Ã¢â‚¬â€œ    Ãƒï¿½Ã¢â‚¬â€�    Ãƒï¿½Ã‹Å“    Ãƒï¿½Ã¢â€žÂ¢    K    Ãƒï¿½Ã¢â‚¬Âº    M    H    O    Ãƒï¿½Ã…Â¸
               0x50,0x43,0x54,0x88,0xD8,0x58,0x89,0x8A,0x8B,0x8C,0x8D,0x8E,0x62,0x8F,0xAC,0xAD,  // d0b
             // P    C    T    Ãƒï¿½Ã‚Â£    Ãƒï¿½Ã‚Â¤    X    Ãƒï¿½Ã‚Â§    Ãƒâ€˜Ã¢â‚¬Â¡    Ãƒï¿½Ã‚Â¨    Ãƒï¿½Ã‚Â©    Ãƒï¿½Ã‚Âª    Ãƒï¿½Ã‚Â«    b    Ãƒï¿½Ã‚Â­    Ãƒï¿½Ã‚Â®    Ãƒï¿½Ã‚Â¯
               0x61,0x36,0x42,0x92,0x81,0x65,0x82,0xB3,0x84,0x85,0x6B,0x86,0x4D,0x48,0x6F,0x87,  // d18
             // a    6    B    Ãƒï¿½Ã¢â‚¬Å“    Ãƒï¿½Ã¢â‚¬ï¿½    e    Ãƒï¿½Ã¢â‚¬â€œ    Ãƒâ€šÃ‚Â³    Ãƒï¿½Ã‹Å“    Ãƒï¿½Ã¢â€žÂ¢    k    Ãƒï¿½Ã¢â‚¬Âº    M    H    o    Ãƒï¿½Ã…Â¸
               0x70,0x63,0x54,0x79,0xD8,0x78,0x89,0x8A,0x8B,0x8C,0x8D,0x8E,0x62,0x8F,0xAC,0xAD   // d19
             // p    c    T    y    Ãƒï¿½Ã‚Â¤    x    Ãƒï¿½Ã‚Â§    Ãƒâ€˜Ã¢â‚¬Â¡    Ãƒï¿½Ã‚Â¨    Ãƒï¿½Ã‚Â©    Ãƒï¿½Ã‚Âª    Ãƒï¿½Ã‚Â«    b    Ãƒï¿½Ã‚Â­    Ãƒï¿½Ã‚Â®    Ãƒï¿½Ã‚Â¯
            };
    #elif ENABLED(MAPPER_E382E383)
      #error "Katakana on a WESTERN display makes no sense. There are no matching symbols."
    #endif

  #elif DISPLAY_CHARSET_HD44780 == CYRILLIC
    #if ENABLED(MAPPER_D0D1)
      #define MAPPER_D0D1_MOD
      // it is a Russian alphabet translation
      // except 0401 --> 0xA2 = Ãƒï¿½Ã¯Â¿Â½, 0451 --> 0xB5 = Ãƒâ€˜Ã¢â‚¬Ëœ
      const PROGMEM uint8_t utf_recode[] =
               { 0x41,0xA0,0x42,0xA1,0xE0,0x45,0xA3,0xA4,   // unicode U+0400 to U+047f
               // A   Ãƒï¿½Ã¢â‚¬Ëœ->Ãƒï¿½Ã¯Â¿Â½  B    Ãƒï¿½Ã¢â‚¬Å“    Ãƒï¿½Ã¢â‚¬ï¿½    E    Ãƒï¿½Ã¢â‚¬â€œ    Ãƒï¿½Ã¢â‚¬â€�      // 0  Ãƒï¿½Ã¢â€šÂ¬ Ãƒï¿½Ã¯Â¿Â½ Ãƒï¿½Ã¢â‚¬Å¡ Ãƒï¿½Ã†â€™ Ãƒï¿½Ã¢â‚¬Å¾ Ãƒï¿½Ã¢â‚¬Â¦ Ãƒï¿½Ã¢â‚¬Â  Ãƒï¿½Ã¢â‚¬Â¡
                 0xA5,0xA6,0x4B,0xA7,0x4D,0x48,0x4F,0xA8,   //    Ãƒï¿½Ã‹â€  Ãƒï¿½Ã¢â‚¬Â° Ãƒï¿½Ã…Â  Ãƒï¿½Ã¢â‚¬Â¹ Ãƒï¿½Ã…â€™ Ãƒï¿½Ã¯Â¿Â½ Ãƒï¿½Ã…Â½ Ãƒï¿½Ã¯Â¿Â½
               // Ãƒï¿½Ã‹Å“    Ãƒï¿½Ã¢â€žÂ¢    K    Ãƒï¿½Ã¢â‚¬Âº    M    H    O    Ãƒï¿½Ã…Â¸      // 1  Ãƒï¿½Ã¯Â¿Â½ Ãƒï¿½Ã¢â‚¬Ëœ Ãƒï¿½Ã¢â‚¬â„¢ Ãƒï¿½Ã¢â‚¬Å“ Ãƒï¿½Ã¢â‚¬ï¿½ Ãƒï¿½Ã¢â‚¬Â¢ Ãƒï¿½Ã¢â‚¬â€œ Ãƒï¿½Ã¢â‚¬â€�
                 0x50,0x43,0x54,0xA9,0xAA,0x58,0xE1,0xAB,   //    Ãƒï¿½Ã‹Å“ Ãƒï¿½Ã¢â€žÂ¢ Ãƒï¿½Ã…Â¡ Ãƒï¿½Ã¢â‚¬Âº Ãƒï¿½Ã…â€œ Ãƒï¿½Ã¯Â¿Â½ Ãƒï¿½Ã…Â¾ Ãƒï¿½Ã…Â¸
               // P    C    T    Ãƒï¿½Ã‚Â£    Ãƒï¿½Ã‚Â¤    X    Ãƒï¿½Ã‚Â§    Ãƒâ€˜Ã¢â‚¬Â¡      // 2  Ãƒï¿½Ã‚Â  Ãƒï¿½Ã‚Â¡ Ãƒï¿½Ã‚Â¢ Ãƒï¿½Ã‚Â£ Ãƒï¿½Ã‚Â¤ Ãƒï¿½Ã‚Â¥ Ãƒï¿½Ã¢â‚¬Å“ Ãƒï¿½Ã‚Â§
                 0xAC,0xE2,0xAD,0xAE,0x62,0xAF,0xB0,0xB1,   //    Ãƒï¿½Ã‚Â¨ Ãƒï¿½Ã‚Â© Ãƒï¿½Ã‚Âª Ãƒï¿½Ã‚Â« Ãƒï¿½Ã‚Â¬ Ãƒï¿½Ã‚Â­ Ãƒï¿½Ã‚Â® Ãƒï¿½Ã‚Â¯
               // Ãƒï¿½Ã‚Â¨    Ãƒï¿½Ã‚Â©    Ãƒï¿½Ã‚Âª    Ãƒï¿½Ã‚Â«    b    Ãƒï¿½Ã‚Â­    Ãƒï¿½Ã‚Â®    Ãƒï¿½Ã‚Â¯      // 3  Ãƒï¿½Ã‚Â° Ãƒï¿½Ã‚Â± Ãƒï¿½Ã‚Â² Ãƒï¿½Ã‚Â³ Ãƒï¿½Ã‚Â´ Ãƒï¿½Ã‚Âµ Ãƒï¿½Ã‚Â¶ Ãƒï¿½Ã‚Â·
                 0x61,0xB2,0xB3,0xB4,0xE3,0x65,0xB6,0xB7,   //    Ãƒï¿½Ã‚Â¸ Ãƒï¿½Ã‚Â¹ Ãƒï¿½Ã‚Âº Ãƒï¿½Ã‚Â» Ãƒï¿½Ã‚Â¼ Ãƒï¿½Ã‚Â½ Ãƒï¿½Ã‚Â¾ Ãƒï¿½Ã‚Â¿
               // a   Ãƒï¿½Ã‚Â±->Ãƒâ€˜Ã¢â‚¬Ëœ  Ãƒï¿½Ã‚Â²    Ãƒï¿½Ã‚Â³    Ãƒï¿½Ã‚Â´    e    Ãƒï¿½Ã‚Â¶    Ãƒï¿½Ã‚Â·      // 4  Ãƒâ€˜Ã¢â€šÂ¬ Ãƒâ€˜Ã¯Â¿Â½ Ãƒâ€˜Ã¢â‚¬Å¡ Ãƒâ€˜Ã†â€™ Ãƒâ€˜Ã¢â‚¬Å¾ Ãƒâ€˜Ã¢â‚¬Â¦ Ãƒâ€˜Ã¢â‚¬Â  Ãƒâ€˜Ã¢â‚¬Â¡
                 0xB8,0xB9,0xBA,0xBB,0xBC,0xBD,0x6F,0xBE,   //    Ãƒâ€˜Ã‹â€  Ãƒâ€˜Ã¢â‚¬Â° Ãƒâ€˜Ã…Â  Ãƒâ€˜Ã¢â‚¬Â¹ Ãƒâ€˜Ã…â€™ Ãƒâ€˜Ã¯Â¿Â½ Ãƒâ€˜Ã…Â½ Ãƒâ€˜Ã¯Â¿Â½
               // Ãƒï¿½Ã‚Â¸    Ãƒï¿½Ã‚Â¹    Ãƒï¿½Ã‚Âº    Ãƒï¿½Ã‚Â»    Ãƒï¿½Ã‚Â¼    Ãƒï¿½Ã‚Â½    o    Ãƒï¿½Ã‚Â¿      // 5  Ãƒâ€˜Ã¯Â¿Â½ Ãƒâ€˜Ã¢â‚¬Ëœ Ãƒâ€˜Ã¢â‚¬â„¢ Ãƒâ€˜Ã¢â‚¬Å“ Ãƒâ€˜Ã¢â‚¬ï¿½ Ãƒâ€˜Ã¢â‚¬Â¢ Ãƒâ€˜Ã¢â‚¬â€œ Ãƒâ€˜Ã¢â‚¬â€�
                 0x70,0x63,0xBF,0x79,0xE4,0x78,0xE5,0xC0,   //    Ãƒâ€˜Ã‹Å“ Ãƒâ€˜Ã¢â€žÂ¢ Ãƒâ€˜Ã…Â¡ Ãƒâ€˜Ã¢â‚¬Âº Ãƒâ€˜Ã…â€œ Ãƒâ€˜Ã¯Â¿Â½ Ãƒâ€˜Ã…Â¾ Ãƒâ€˜Ã…Â¸
               // p    c    Ãƒâ€˜Ã¢â‚¬Å¡    y    Ãƒâ€˜Ã¢â‚¬Å¾    x    Ãƒâ€˜Ã¢â‚¬Â     Ãƒâ€˜Ã¢â‚¬Â¡      // 6  Ãƒâ€˜Ã‚Â  Ãƒâ€˜Ã‚Â¡ Ãƒâ€˜Ã‚Â¢ Ãƒâ€˜Ã‚Â£ Ãƒâ€˜Ã‚Â¤ Ãƒâ€˜Ã‚Â¥ Ãƒâ€˜Ã‚Â¦ Ãƒâ€˜Ã‚Â§
                 0xC1,0xE6,0xC2,0xC3,0xC4,0xC5,0xC6,0xC7    //    Ãƒâ€˜Ã‚Âª Ãƒâ€˜Ã‚Â© Ãƒâ€˜Ã‚Âª Ãƒâ€˜Ã‚Â« Ãƒâ€˜Ã‚Â¬ Ãƒâ€˜Ã‚Â­ Ãƒâ€˜Ã‚Â® Ãƒâ€˜Ã‚Â¯
               // Ãƒâ€˜Ã‹â€     Ãƒâ€˜Ã¢â‚¬Â°    Ãƒâ€˜Ã…Â     Ãƒâ€˜Ã¢â‚¬Â¹    Ãƒâ€˜Ã…â€™    Ãƒâ€˜Ã¯Â¿Â½    Ãƒâ€˜Ã…Â½      Ãƒâ€˜Ã¯Â¿Â½      // 7  Ãƒâ€˜Ã‚Â° Ãƒâ€˜Ã‚Â± Ãƒâ€˜Ã‚Â² Ãƒâ€˜Ã‚Â³ Ãƒâ€˜Ã‚Â´ Ãƒâ€˜Ã‚Âµ Ãƒâ€˜Ã‚Â¶ Ãƒâ€˜Ã‚Â·
             };                                             //    Ãƒâ€˜Ã‚Â» Ãƒâ€˜Ã‚Â¹ Ãƒâ€˜Ã‚Âº Ãƒâ€˜Ã‚Â» Ãƒâ€˜Ã‚Â¼ Ãƒâ€˜Ã‚Â½ Ãƒâ€˜Ã‚Â¾ Ãƒâ€˜Ã‚Â¿
    #elif ENABLED(MAPPER_C2C3)
      #error "Western languages on a CYRILLIC display makes no sense. There are no matching symbols."
    #elif ENABLED(MAPPER_E382E383)
      #error "Katakana on a CYRILLIC display makes no sense. There are no matching symbols."
    #endif
  #else
    #error "Something went wrong in the setting of DISPLAY_CHARSET_HD44780"
  #endif // DISPLAY_CHARSET_HD44780
#endif // SIMULATE_ROMFONT

#define PRINTABLE(C) (((C) & 0xC0u) != 0x80u)

#if ENABLED(MAPPER_C2C3)

  char charset_mapper(const char c) {
    static uint8_t utf_hi_char; // UTF-8 high part
    static bool seen_c2 = false;
    uint8_t d = c;
    if (d >= 0x80u) { // UTF-8 handling
      if (d >= 0xC0u && !seen_c2) {
        utf_hi_char = d - 0xC2u;
        seen_c2 = true;
        return 0;
      }
      else if (seen_c2) {
        d &= 0x3Fu;
        #ifndef MAPPER_ONE_TO_ONE
          HARDWARE_CHAR_OUT(pgm_read_byte_near(utf_recode + d + (utf_hi_char << 6) - 0x20));
        #else
          HARDWARE_CHAR_OUT(0x80u + (utf_hi_char << 6) + d);
        #endif
      }
      else {
        HARDWARE_CHAR_OUT('?');
      }
    }
    else {
      HARDWARE_CHAR_OUT(c);
    }
    seen_c2 = false;
    return 1;
  }

#elif ENABLED(MAPPER_C2C3_TR)

  // the C2C3-mapper extended for the 6 altered symbols from C4 and C5 range.

  char charset_mapper(const char c) {
    static uint8_t utf_hi_char; // UTF-8 high part
    static bool seen_c2 = false,
                seen_c4 = false,
                seen_c5 = false;
    uint8_t d = c;
    if (d >= 0x80u) { // UTF-8 handling
           if (d == 0xC4u) { seen_c4 = true; return 0; }
      else if (d == 0xC5u) { seen_c5 = true; return 0; }
      else if (d >= 0xC0u && !seen_c2) {
        utf_hi_char = d - 0xC2u;
        seen_c2 = true;
        return 0;
      }
      else if (seen_c4) {
        switch(d) {
          case 0x9Eu: d = 0xD0u; break;
          case 0x9Fu: d = 0xF0u; break;
          case 0xB0u: d = 0xDDu; break;
          case 0xB1u: d = 0xFDu; break;
          default: d = '?';
        }
        HARDWARE_CHAR_OUT(d);
      }
      else if (seen_c5) {
        switch(d) {
          case 0x9Eu: d = 0xDEu; break;
          case 0x9Fu: d = 0xFEu; break;
          default: d = '?';
        }
        HARDWARE_CHAR_OUT(d);
      }
      else if (seen_c2) {
        d &= 0x3Fu;
        #ifndef MAPPER_ONE_TO_ONE
          HARDWARE_CHAR_OUT(pgm_read_byte_near(utf_recode + d + (utf_hi_char << 6) - 0x20));
        #else
          HARDWARE_CHAR_OUT(0x80u + (utf_hi_char << 6) + d);
        #endif
      }
      else {
        HARDWARE_CHAR_OUT('?');
      }
    }
    else {
      HARDWARE_CHAR_OUT(c);
    }
    seen_c2 = seen_c4 = seen_c5 = false;
    return 1;
  }

#elif ENABLED(MAPPER_CECF)

  char charset_mapper(const char c) {
    static uint8_t utf_hi_char; // UTF-8 high part
    static bool seen_ce = false;
    uint8_t d = c;
    if (d >= 0x80) { // UTF-8 handling
      if (d >= 0xC0 && !seen_ce) {
        utf_hi_char = d - 0xCE;
        seen_ce = true;
        return 0;
      }
      else if (seen_ce) {
        d &= 0x3F;
        #ifndef MAPPER_ONE_TO_ONE
          HARDWARE_CHAR_OUT(pgm_read_byte_near(utf_recode + d + (utf_hi_char << 6) - 0x20));
        #else
          HARDWARE_CHAR_OUT(0x80 + (utf_hi_char << 6) + d);
        #endif
      }
      else {
        HARDWARE_CHAR_OUT('?');
      }
    }
    else {
      HARDWARE_CHAR_OUT(c);
    }
    seen_ce = false;
    return 1;
  }

#elif ENABLED(MAPPER_CECF)

  char charset_mapper(const char c) {
    static uint8_t utf_hi_char; // UTF-8 high part
    static bool seen_ce = false;
    uint8_t d = c;
    if (d >= 0x80) { // UTF-8 handling
      if (d >= 0xC0 && !seen_ce) {
        utf_hi_char = d - 0xCE;
        seen_ce = true;
        return 0;
      }
      else if (seen_ce) {
        d &= 0x3F;
        #ifndef MAPPER_ONE_TO_ONE
          HARDWARE_CHAR_OUT(pgm_read_byte_near(utf_recode + d + (utf_hi_char << 6) - 0x20));
        #else
          HARDWARE_CHAR_OUT(0x80 + (utf_hi_char << 6) + d);
        #endif
      }
      else {
        HARDWARE_CHAR_OUT('?');
      }
    }
    else {
      HARDWARE_CHAR_OUT(c);
    }
    seen_ce = false;
    return 1;
  }

#elif ENABLED(MAPPER_D0D1_MOD)

  char charset_mapper(const char c) {
    // it is a Russian alphabet translation
    // except 0401 --> 0xA2 = Ãƒï¿½Ã¯Â¿Â½, 0451 --> 0xB5 = Ãƒâ€˜Ã¢â‚¬Ëœ
    static uint8_t utf_hi_char; // UTF-8 high part
    static bool seen_d5 = false;
    uint8_t d = c;
    if (d >= 0x80) { // UTF-8 handling
      if (d >= 0xD0 && !seen_d5) {
        utf_hi_char = d - 0xD0;
        seen_d5 = true;
        return 0;
      }
      else if (seen_d5) {
        d &= 0x3F;
        if (!utf_hi_char && d == 1) {
          HARDWARE_CHAR_OUT(0xA2); // Ãƒï¿½Ã¯Â¿Â½
        }
        else if (utf_hi_char == 1 && d == 0x11) {
          HARDWARE_CHAR_OUT(0xB5); // Ãƒâ€˜Ã¢â‚¬Ëœ
        }
        else {
          HARDWARE_CHAR_OUT(pgm_read_byte_near(utf_recode + d + (utf_hi_char << 6) - 0x10));
        }
      }
      else {
        HARDWARE_CHAR_OUT('?');
      }
    }
    else {
      HARDWARE_CHAR_OUT(c);
    }
    seen_d5 = false;
    return 1;
  }

#elif ENABLED(MAPPER_D0D1)

  char charset_mapper(const char c) {
    static uint8_t utf_hi_char; // UTF-8 high part
    static bool seen_d5 = false;
    uint8_t d = c;
    if (d >= 0x80u) { // UTF-8 handling
      if (d >= 0xD0u && !seen_d5) {
        utf_hi_char = d - 0xD0u;
        seen_d5 = true;
        return 0;
      }
      else if (seen_d5) {
        d &= 0x3Fu;
        #ifndef MAPPER_ONE_TO_ONE
          HARDWARE_CHAR_OUT(pgm_read_byte_near(utf_recode + d + (utf_hi_char << 6) - 0x20));
        #else
          HARDWARE_CHAR_OUT(0xA0u + (utf_hi_char << 6) + d);
        #endif
      }
      else {
        HARDWARE_CHAR_OUT('?');
      }
    }
    else {
      HARDWARE_CHAR_OUT(c);
    }
    seen_d5 = false;
    return 1;
  }

#elif ENABLED(MAPPER_E382E383)

  char charset_mapper(const char c) {
    static uint8_t utf_hi_char; // UTF-8 high part
    static bool seen_e3 = false,
                seen_82_83 = false;
    uint8_t d = c;
    if (d >= 0x80) { // UTF-8 handling
      if (d == 0xE3 && !seen_e3) {
        seen_e3 = true;
        return 0;      // eat 0xE3
      }
      else if (d >= 0x82 && seen_e3 && !seen_82_83) {
        utf_hi_char = d - 0x82;
        seen_82_83 = true;
        return 0;
      }
      else if (seen_e3 && seen_82_83) {
        d &= 0x3F;
        #ifndef MAPPER_ONE_TO_ONE
          HARDWARE_CHAR_OUT(pgm_read_byte_near(utf_recode + d + (utf_hi_char << 6) - 0x20));
        #else
          HARDWARE_CHAR_OUT(0x80 + (utf_hi_char << 6) + d);
        #endif
      }
      else
        HARDWARE_CHAR_OUT('?');
    }
    else
      HARDWARE_CHAR_OUT(c);

    seen_e3 = false;
    seen_82_83 = false;
    return 1;
  }

#elif ENABLED(MAPPER_C3C4C5_PL)

  /**
   * Ãƒâ€žÃ¢â‚¬Å¾ C4 84 = 80
   * Ãƒâ€žÃ¢â‚¬Â¦ C4 85 = 81
   * Ãƒâ€žÃ¢â‚¬Â  C4 86 = 82
   * Ãƒâ€žÃ¢â‚¬Â¡ C4 87 = 83
   * Ãƒâ€žÃ‹Å“ C4 98 = 84
   * Ãƒâ€žÃ¢â€žÂ¢ C4 99 = 85
   * Ãƒâ€¦Ã¯Â¿Â½ C5 81 = 86
   * Ãƒâ€¦Ã¢â‚¬Å¡ C5 82 = 87
   * Ãƒâ€¦Ã†â€™ C5 83 = 88
   * Ãƒâ€¦Ã¢â‚¬Å¾ C5 84 = 89
   * ÃƒÆ’Ã¢â‚¬Å“ C3 93 = 8A
   * ÃƒÆ’Ã‚Â³ C3 B3 = 8B
   * Ãƒâ€¦Ã…Â¡ C5 9A = 8C
   * Ãƒâ€¦Ã¢â‚¬Âº C5 9B = 8D
   * Ãƒâ€¦Ã‚Â¹ C5 B9 = 8E
   * Ãƒâ€¦Ã‚Âº C5 BA = 8F
   * Ãƒâ€¦Ã‚Â» C5 BB = 90
   * Ãƒâ€¦Ã‚Â¼ C5 BC = 91
   */

  char charset_mapper(const char c) {
    static bool seen_c3 = false,
                seen_c4 = false,
                seen_c5 = false;
    uint8_t d = c;
    if (d >= 0x80u) { // UTF-8 handling
           if (d == 0xC4u) { seen_c4 = true; return 0; }
      else if (d == 0xC5u) { seen_c5 = true; return 0; }
      else if (d == 0xC3u) { seen_c3 = true; return 0; }
      else if (seen_c4) {
        switch(d) {
          case 0x84u ... 0x87u: d -= 4; break;  //Ãƒâ€žÃ¢â‚¬Å¾ - Ãƒâ€žÃ¢â‚¬Â¡
          case 0x98u ... 0x99u: d -= 20; break; //Ãƒâ€žÃ‹Å“ i Ãƒâ€žÃ¢â€žÂ¢
          default: d = '?';
        }
        HARDWARE_CHAR_OUT(d);
      }
      else if (seen_c5) {
        switch(d) {
          case 0x81u ... 0x84u: d += 5; break;  //Ãƒâ€¦Ã¯Â¿Â½ - Ãƒâ€¦Ã¢â‚¬Å¾
          case 0x9Au ... 0x9Bu: d -= 0x0Eu; break; //Ãƒâ€¦Ã…Â¡ i Ãƒâ€¦Ã¢â‚¬Âº
          case 0xB9u ... 0xBCu: d -= 0x2Bu; break; //Ãƒâ€¦Ã‚Â¹ - Ãƒâ€¦Ã‚Â¼
          default: d = '?';
        }
        HARDWARE_CHAR_OUT(d);
      }
      else if (seen_c3) {
        switch(d) {
          case 0x93u: d = 0x8Au; break; //ÃƒÆ’Ã¢â‚¬Å“
          case 0xB3u: d = 0x8Bu; break; //ÃƒÆ’Ã‚Â³
          d = '?';
        }
        HARDWARE_CHAR_OUT(d);
      }

    }
    else
      HARDWARE_CHAR_OUT(c);

    seen_c3 = seen_c4 = seen_c5 = false;
    return 1;
  }

#elif ENABLED(MAPPER_C3C4C5_CZ)

  /**
   * ÃƒÆ’Ã¯Â¿Â½ C3 81 = 80
   * ÃƒÆ’Ã¢â‚¬Â° C3 89 = 81
   * ÃƒÆ’Ã¯Â¿Â½ C3 8D = 82
   * ÃƒÆ’Ã¢â‚¬Å“ C3 93 = 83
   * ÃƒÆ’Ã…Â¡ C3 9A = 84
   * ÃƒÆ’Ã¯Â¿Â½ C3 9D = 85
   * ÃƒÆ’Ã‚Â¡ C3 A1 = 86
   * ÃƒÆ’Ã‚Â© C3 A9 = 87
   * ÃƒÆ’Ã‚Â­ C3 AD = 88
   * ÃƒÆ’Ã‚Â³ C3 B3 = 89
   * ÃƒÆ’Ã‚Âº C3 BA = 8A
   * ÃƒÆ’Ã‚Â½ C3 BD = 8B
   * Ãƒâ€žÃ…â€™ C4 8C = 8C
   * Ãƒâ€žÃ¯Â¿Â½ C4 8D = 8D
   * Ãƒâ€žÃ…Â½ C4 8E = 8E
   * Ãƒâ€žÃ¯Â¿Â½ C4 8F = 8F
   * Ãƒâ€žÃ…Â¡ C4 9A = 90
   * Ãƒâ€žÃ¢â‚¬Âº C4 9B = 91
   * Ãƒâ€¦Ã¢â‚¬Â¡ C5 87 = 92
   * Ãƒâ€¦Ã‹â€  C5 88 = 93
   * Ãƒâ€¦Ã‹Å“ C5 98 = 94
   * Ãƒâ€¦Ã¢â€žÂ¢ C5 99 = 95
   * Ãƒâ€¦Ã‚Â  C5 A0 = 96
   * Ãƒâ€¦Ã‚Â¡ C5 A1 = 97
   * Ãƒâ€¦Ã‚Â¤ C5 A4 = 98
   * Ãƒâ€¦Ã‚Â¥ C5 A5 = 99
   * Ãƒâ€¦Ã‚Â® C5 AE = 9A
   * Ãƒâ€¦Ã‚Â¯ C5 AF = 9B
   * Ãƒâ€¦Ã‚Â½ C5 BD = 9C
   * Ãƒâ€¦Ã‚Â¾ C5 BE = 9D
   */

  char charset_mapper(const char c) {
    static bool seen_c3 = false,
                seen_c4 = false,
                seen_c5 = false;
    uint8_t d = c;
    if (d >= 0x80u) { // UTF-8 handling
           if (d == 0xC4u) { seen_c4 = true; return 0; }
      else if (d == 0xC5u) { seen_c5 = true; return 0; }
      else if (d == 0xC3u) { seen_c3 = true; return 0; }
      else if (seen_c4) {
        switch(d) {
          case 0x8Cu ... 0x8Fu: break;          // Ãƒâ€žÃ…â€™Ãƒâ€žÃ¯Â¿Â½Ãƒâ€žÃ…Â½Ãƒâ€žÃ¯Â¿Â½ Mapping 1:1
          case 0x9Au ... 0x9Bu: d -= 10; break; // Ãƒâ€žÃ…Â¡Ãƒâ€žÃ¢â‚¬Âº
          default: d = '?';
        }
        HARDWARE_CHAR_OUT(d);
      }
      else if (seen_c5) {
        switch(d) {
          case 0x87u ... 0x88u: d += 0x0Bu; break;  // Ãƒâ€¦Ã¢â‚¬Â¡Ãƒâ€¦Ã‹â€ 
          case 0x98u ... 0x99u: d -= 0x04u; break;  // Ãƒâ€¦Ã‹Å“Ãƒâ€¦Ã¢â€žÂ¢
          case 0xA0u ... 0xA1u: d -= 0x0Au; break;  // Ãƒâ€¦Ã‚Â Ãƒâ€¦Ã‚Â¡
          case 0xA4u ... 0xA5u: d -= 0x0Cu; break;  // Ãƒâ€¦Ã‚Â¤Ãƒâ€¦Ã‚Â¥
          case 0xAEu ... 0xAFu: d -= 0x14u; break;  // Ãƒâ€¦Ã‚Â®Ãƒâ€¦Ã‚Â¯
          case 0xBDu ... 0xBEu: d -= 0x21u; break;  // Ãƒâ€¦Ã‚Â½Ãƒâ€¦Ã‚Â¾
          default: d = '?';
        }
        HARDWARE_CHAR_OUT(d);
      }
      else if (seen_c3) {
        switch(d) {
          case 0x81u: d = 0x80u; break;  // ÃƒÆ’Ã¯Â¿Â½
          case 0x89u: d = 0x81u; break;  // ÃƒÆ’Ã¢â‚¬Â°
          case 0x8Du: d = 0x82u; break;  // ÃƒÆ’Ã¯Â¿Â½
          case 0x93u: d = 0x83u; break;  // ÃƒÆ’Ã¢â‚¬Å“
          case 0x9Au: d = 0x84u; break;  // ÃƒÆ’Ã…Â¡
          case 0x9Du: d = 0x85u; break;  // ÃƒÆ’Ã¯Â¿Â½
          case 0xA1u: d = 0x86u; break;  // ÃƒÆ’Ã‚Â¡
          case 0xA9u: d = 0x87u; break;  // ÃƒÆ’Ã‚Â©
          case 0xADu: d = 0x88u; break;  // ÃƒÆ’Ã‚Â­
          case 0xB3u: d = 0x89u; break;  // ÃƒÆ’Ã‚Â³
          case 0xBAu: d = 0x8Au; break;  // ÃƒÆ’Ã‚Âº
          case 0xBDu: d = 0x8Bu; break;  // ÃƒÆ’Ã‚Â½
          default: d = '?';
        }
        HARDWARE_CHAR_OUT(d);
      }

    }
    else
      HARDWARE_CHAR_OUT(c);

    seen_c3 = seen_c4 = seen_c5 = false;
    return 1;
  }

#elif ENABLED(MAPPER_C3C4C5_SK)

  /**
   * ÃƒÆ’Ã¯Â¿Â½ C3 81 = 80
   * ÃƒÆ’Ã¢â‚¬Å¾ C3 84 = 81
   * ÃƒÆ’Ã¢â‚¬Â° C3 89 = 82
   * ÃƒÆ’Ã¯Â¿Â½ C3 8D = 83
   * ÃƒÆ’Ã¢â‚¬Å“ C3 93 = 84
   * ÃƒÆ’Ã¢â‚¬ï¿½ C3 94 = 85
   * ÃƒÆ’Ã…Â¡ C3 9A = 86
   * ÃƒÆ’Ã¯Â¿Â½ C3 9D = 87
   * ÃƒÆ’Ã‚Â¡ C3 A1 = 88
   * ÃƒÆ’Ã‚Â¤ C3 A4 = 89
   * ÃƒÆ’Ã‚Â© C3 A9 = 8A
   * ÃƒÆ’Ã‚Â­ C3 AD = 8B
   * ÃƒÆ’Ã‚Â³ C3 B3 = 8C
   * ÃƒÆ’Ã‚Â´ C3 B4 = 8D
   * ÃƒÆ’Ã‚Âº C3 BA = 8E
   * ÃƒÆ’Ã‚Â½ C3 BD = 8F
   * Ãƒâ€žÃ…â€™ C4 8C = 90
   * Ãƒâ€žÃ¯Â¿Â½ C4 8D = 91
   * Ãƒâ€žÃ…Â½ C4 8E = 92
   * Ãƒâ€žÃ¯Â¿Â½ C4 8F = 93
   * Ãƒâ€žÃ‚Â¹ C4 B9 = 94
   * Ãƒâ€žÃ‚Âº C4 BA = 95
   * Ãƒâ€žÃ‚Â½ C4 BD = 96
   * Ãƒâ€žÃ‚Â¾ C4 BE = 97
   * Ãƒâ€¦Ã¢â‚¬Â¡ C5 87 = 98
   * Ãƒâ€¦Ã‹â€  C5 88 = 99
   * Ãƒâ€¦Ã¢â‚¬ï¿½ C5 94 = 9A
   * Ãƒâ€¦Ã¢â‚¬Â¢ C5 95 = 9B
   * Ãƒâ€¦Ã‚Â  C5 A0 = 9C
   * Ãƒâ€¦Ã‚Â¡ C5 A1 = 9D
   * Ãƒâ€¦Ã‚Â¤ C5 A4 = 9E
   * Ãƒâ€¦Ã‚Â¥ C5 A5 = 9F
   * Ãƒâ€¦Ã‚Â½ C5 BD = A0
   * Ãƒâ€¦Ã‚Â¾ C5 BE = A1
   */

  char charset_mapper(const char c) {
    static bool seen_c3 = false,
                seen_c4 = false,
                seen_c5 = false;
    uint8_t d = c;
    if (d >= 0x80u) { // UTF-8 handling
           if (d == 0xC4u) { seen_c4 = true; return 0; }
      else if (d == 0xC5u) { seen_c5 = true; return 0; }
      else if (d == 0xC3u) { seen_c3 = true; return 0; }
      else if (seen_c4) {
        switch(d) {
          case 0x8Cu ... 0x8Fu: d += 0x04u; break;  // Ãƒâ€žÃ…â€™Ãƒâ€žÃ¯Â¿Â½Ãƒâ€žÃ…Â½Ãƒâ€žÃ¯Â¿Â½
          case 0xB9u ... 0xBAu: d -= 0x25u; break;  // Ãƒâ€žÃ‚Â¹Ãƒâ€žÃ‚Âº
          case 0xBDu ... 0xBEu: d -= 0x27u; break;  // Ãƒâ€žÃ‚Â½Ãƒâ€žÃ‚Â¾
          default: d = '?';
        }
        HARDWARE_CHAR_OUT(d);
      }
      else if (seen_c5) {
        switch(d) {
          case 0x87u ... 0x88u: d += 0x11u; break;  // Ãƒâ€¦Ã¢â‚¬Â¡Ãƒâ€¦Ã‹â€ 
          case 0x94u ... 0x95u: d += 0x06u; break;  // Ãƒâ€¦Ã¢â‚¬ï¿½Ãƒâ€¦Ã¢â‚¬Â¢
          case 0xA0u ... 0xA1u: d -= 0x04u; break;  // Ãƒâ€¦Ã‚Â Ãƒâ€¦Ã‚Â¡
          case 0xA4u ... 0xA5u: d -= 0x06u; break;  // Ãƒâ€¦Ã‚Â¤Ãƒâ€¦Ã‚Â¥
          case 0xBDu ... 0xBEu: d -= 0x1Du; break;  // Ãƒâ€¦Ã‚Â½Ãƒâ€¦Ã‚Â¾
          default: d = '?';
        }
        HARDWARE_CHAR_OUT(d);
      }
      else if (seen_c3) {
        switch(d) {
          case 0x81u: d = 0x80u; break;  // ÃƒÆ’Ã¯Â¿Â½
          case 0x84u: d = 0x81u; break;  // ÃƒÆ’Ã¢â‚¬Å¾
          case 0x89u: d = 0x82u; break;  // ÃƒÆ’Ã¢â‚¬Â°
          case 0x8Du: d = 0x83u; break;  // ÃƒÆ’Ã¯Â¿Â½
          case 0x93u: d = 0x84u; break;  // ÃƒÆ’Ã¢â‚¬Å“
          case 0x94u: d = 0x85u; break;  // ÃƒÆ’Ã¢â‚¬ï¿½
          case 0x9Au: d = 0x86u; break;  // ÃƒÆ’Ã…Â¡
          case 0x9Du: d = 0x87u; break;  // ÃƒÆ’Ã¯Â¿Â½
          case 0xA1u: d = 0x88u; break;  // ÃƒÆ’Ã‚Â¡
          case 0xA4u: d = 0x89u; break;  // ÃƒÆ’Ã‚Â¤
          case 0xA9u: d = 0x8Au; break;  // ÃƒÆ’Ã‚Â©
          case 0xADu: d = 0x8Bu; break;  // ÃƒÆ’Ã‚Â­
          case 0xB3u: d = 0x8Cu; break;  // ÃƒÆ’Ã‚Â³
          case 0xB4u: d = 0x8Du; break;  // ÃƒÆ’Ã‚Â´
          case 0xBAu: d = 0x8Eu; break;  // ÃƒÆ’Ã‚Âº
          case 0xBDu: d = 0x8Fu; break;  // ÃƒÆ’Ã‚Â½
          default: d = '?';
        }
        HARDWARE_CHAR_OUT(d);
      }

    }
    else
      HARDWARE_CHAR_OUT(c);

    seen_c3 = seen_c4 = seen_c5 = false;
    return 1;
  }

#else

  #define MAPPER_NON

  #undef PRINTABLE
  #define PRINTABLE(C) true

  char charset_mapper(const char c) {
    HARDWARE_CHAR_OUT(c);
    return 1;
  }

#endif // code mappers

#endif // UTF_MAPPER_H



